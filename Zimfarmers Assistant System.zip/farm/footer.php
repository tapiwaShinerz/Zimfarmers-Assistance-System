<?php include_once'inc/posts_handler.php';?>
<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>
<div class="row" style="padding-bottom:20px;background-color: #000;color: #FFF">
<div class="col-sm-12">
<h5 class="text-center">Powered by T & N Systems &copy All rights reserved 2017</h5>
<h5 class="text-center">ZIMFARMERS <img src="images/sun.jpg" width="55" height="55" style="border-radius: 60%"> ASSISTANT SYSTEM</h5>
<hr>
<div class="col-sm-3">
<form action="" method="POST">
<span>Subscribe for Agricultural Tips Via Emails</span>
<div class="input-group">
      <input type="email" class="form-control" placeholder="someone@email.com" name="email">
      <span class="input-group-btn">
        <button type="submit" name="subscription1" button class="btn btn-info">Subscribe Now</button>
      </span>
    </div>
</form>
<p><strong>SUPPORT & INFORMATION</strong><span class="glyphicon glyphicon-phone"> 0716-605-802 / 0776-222-978</span></p>
</div>
<div class="col-sm-6 text-center" style="color: #FFF"><a href="index.php">HOME</a><br><a href="contact_us.php">CONTACT US</a><br><a href="district.php">ZIM DISTRICTS</a><br><a href="records.php">FARM MANAGEMENT</a></div>


<div class="col-sm-3">
<form action="" method="POST">
<span>Subscribe for Agricultural Tips Via Phone</span>
<div class="input-group">
      <input type="tel" class="form-control" placeholder="0716 605 802" name="phone"  minlength="10" pattern="[0]{1}[7]{1}[1-9]{1}[1-9]{1}[0-9]{3}[0-9]{3}" title="Enter the correct phone number">
      <span class="input-group-btn">
        <button type="submit" name="subscription2" button class="btn btn-info">Subscribe Now</button>
      </span>
    </div>
</form>
<p><strong>SUPPORT & INFORMATION</strong><span class="glyphicon glyphicon-phone"> 0716-605-802 / 0776-222-978</span></p>
</div>
</div>


</div>
</body>
</html>